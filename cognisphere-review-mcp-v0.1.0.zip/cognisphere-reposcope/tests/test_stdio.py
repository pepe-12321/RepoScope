"""Exercise a real MCP client against the stdio server subprocess, offline."""
import os
from pathlib import Path
import subprocess
import sys
import tempfile
import unittest

from mcp import ClientSession, StdioServerParameters
from mcp.client.stdio import stdio_client


class StdioTests(unittest.IsolatedAsyncioTestCase):
    async def test_protocol_and_local_tool(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            def git(*args):
                subprocess.run(['git', '-C', tmp, *args], check=True, capture_output=True)
            git('init', '-q')
            git('config', 'user.name', 'Test')
            git('config', 'user.email', 'test@example.invalid')
            (root / 'demo.py').write_text('x = 1\n')
            git('add', '.')
            git('commit', '-qm', 'base')
            (root / 'demo.py').write_text('x = 2\n')
            git('commit', '-am', 'head', '-q')
            env = dict(os.environ, REVIEW_LOCAL_ROOT=tmp, REVIEW_GITHUB_REPOS='', REVIEW_ENABLE_PUBLISH='0')
            params = StdioServerParameters(command=sys.executable,
                args=['-m', 'cognisphere_review.server'], env=env)
            async with stdio_client(params) as (read, write):
                async with ClientSession(read, write) as session:
                    await session.initialize()
                    tools = (await session.list_tools()).tools
                    self.assertEqual({t.name for t in tools}, {'review_diff', 'review_pr', 'get_file_context', 'prepare_review', 'publish_review'})
                    self.assertFalse(next(t for t in tools if t.name == 'publish_review').annotations.readOnlyHint)
                    result = await session.call_tool('review_diff', {})
                    self.assertFalse(result.isError)
                    self.assertIn('+x = 2', str(result))
                    invalid = await session.call_tool('publish_review', {'draft_id': 'fake', 'confirmation': 'yes'})
                    self.assertTrue(invalid.isError)
                    prompts = await session.list_prompts()
                    self.assertEqual(prompts.prompts[0].name, 'review_changes')
