import base64
import copy
import os
from pathlib import Path
import subprocess
import tempfile
import unittest
from unittest.mock import patch

import httpx

from cognisphere_review.github import GitHub
from cognisphere_review.local import LocalGit
from cognisphere_review.safety import ReviewError, added_lines, checked_path, redact
from cognisphere_review.service import ReviewService

PATCH = '@@ -1,2 +1,3 @@\n def run(x):\n-    return x\n+    value = 1 / x\n+    return value'


class FakeGitHub:
    def __init__(self):
        self.data = {'state': 'open', 'merged': False, 'changed_files': 1,
                     'head': {'sha': 'a' * 40, 'repo': {'full_name': 'owner/repo'}},
                     'base': {'sha': 'b' * 40}}
        self.entries = [{'filename': 'app.py', 'patch': PATCH, 'additions': 2, 'deletions': 1}]
        self.published = []
        self.remote_reviews = []
        self.fail_after_post = False

    def pr(self, *args):
        return copy.deepcopy(self.data)

    def files(self, *args):
        return self.entries

    def reviews(self, *args):
        return self.remote_reviews

    def publish(self, repo, number, payload):
        self.published.append(copy.deepcopy(payload))
        result = {'html_url': 'https://github.com/owner/repo/pull/1#pullrequestreview-1',
                  'id': 1, 'body': payload['body'], 'commit_id': payload['commit_id']}
        self.remote_reviews.append(result)
        if self.fail_after_post:
            raise ReviewError('Network failed after publication.')
        return result

    def content(self, *args):
        return 'def run(x):\n    value = 1 / x\n    return value\n'


class ServiceTests(unittest.TestCase):
    def setUp(self):
        self.github = FakeGitHub()
        self.service = ReviewService(github=self.github, allowed_repos=['owner/repo'])
        self.finding = {'path': 'app.py', 'line': 2, 'severity': 'P1', 'title': 'Zero input raises an exception',
                        'evidence': 'When x is zero, the new division raises ZeroDivisionError before returning.',
                        'suggestion': 'Handle zero before dividing.'}

    def session(self):
        return self.service.review_pr('owner/repo', 1)['review_id']

    def draft(self):
        return self.service.prepare_review(self.session(), 'One regression found in the changed function.', [self.finding])

    def test_review_is_read_only_and_has_precise_lines(self):
        result = self.service.review_pr('owner/repo', 1)
        self.assertTrue(result['complete'])
        self.assertEqual(result['files'][0]['added_lines'], [2, 3])
        self.assertEqual(self.github.published, [])

    def test_repo_allowlist_and_closed_pr(self):
        with self.assertRaises(ReviewError):
            self.service.review_pr('evil/repo', 1)
        self.github.data['state'] = 'closed'
        with self.assertRaises(ReviewError):
            self.session()

    def test_changed_pr_during_collection(self):
        original = self.github.files
        def changing(*args):
            self.github.data['head']['sha'] = 'c' * 40
            return original(*args)
        self.github.files = changing
        with self.assertRaisesRegex(ReviewError, 'changed'):
            self.session()

    def test_sensitive_and_truncated_patches_mark_partial(self):
        self.github.entries += [{'filename': '.env', 'patch': PATCH},
                                {'filename': 'truncated.py', 'patch': PATCH, 'additions': 9, 'deletions': 1}]
        self.github.data['changed_files'] = 3
        result = self.service.review_pr('owner/repo', 1)
        self.assertFalse(result['complete'])
        self.assertEqual(len(result['skipped']), 2)
        self.assertEqual(len(result['files']), 1)

    def test_sensitive_rename_is_excluded(self):
        self.github.entries[0]['previous_filename'] = '.env'
        self.assertFalse(self.service.review_pr('owner/repo', 1)['files'])

    def test_missing_files_are_rejected(self):
        self.github.data['changed_files'] = 2
        with self.assertRaisesRegex(ReviewError, 'Incomplete'):
            self.session()

    def test_context_is_pinned_and_restricted(self):
        review_id = self.session()
        result = self.service.get_file_context(review_id, 'app.py', 2, 3)
        self.assertEqual(result['commit_sha'], 'a' * 40)
        self.assertIn('2:     value', result['content'])
        for path in ('../app.py', '/etc/passwd', 'other.py', '.env'):
            with self.assertRaises(ReviewError):
                self.service.get_file_context(review_id, path)
        with self.assertRaises(ReviewError):
            self.service.get_file_context(review_id, 'app.py', 1, 201)

    def test_context_redacts_multiline_private_keys(self):
        self.github.content = lambda *args: 'first\n-----BEGIN PRIVATE KEY-----\nvery secret\n-----END PRIVATE KEY-----\nlast'
        text = self.service.get_file_context(self.session(), 'app.py', 1, 5)['content']
        self.assertNotIn('very secret', text)
        self.assertIn('5: last', text)

    def test_only_added_lines_and_no_duplicate_findings(self):
        review_id = self.session()
        invalid = dict(self.finding, line=1)
        with self.assertRaises(ReviewError):
            self.service.prepare_review(review_id, 'A sufficiently long summary.', [invalid])
        with self.assertRaises(ReviewError):
            self.service.prepare_review(review_id, 'A sufficiently long summary.', [self.finding, self.finding])

    def test_secret_review_text_rejected(self):
        with self.assertRaisesRegex(ReviewError, 'credential'):
            self.service.prepare_review(self.session(), 'Do not publish password="real-secret-value"', [self.finding])

    def test_publish_disabled_and_confirmation_required(self):
        draft = self.draft()
        with self.assertRaisesRegex(ReviewError, 'disabled'):
            self.service.publish_review(draft['draft_id'], draft['confirmation'])
        self.service.enable_publish = True
        with self.assertRaisesRegex(ReviewError, 'confirmation'):
            self.service.publish_review(draft['draft_id'], 'yes')
        self.assertFalse(self.github.published)

    def test_stale_head_and_base_block_publication(self):
        self.service.enable_publish = True
        for side in ('head', 'base'):
            with self.subTest(side=side):
                draft = self.draft()
                original = self.github.data[side]['sha']
                self.github.data[side]['sha'] = 'd' * 40
                with self.assertRaisesRegex(ReviewError, 'changed'):
                    self.service.publish_review(draft['draft_id'], draft['confirmation'])
                self.github.data[side]['sha'] = original
        self.assertFalse(self.github.published)

    def test_publish_exact_payload_once(self):
        draft = self.draft()
        self.service.enable_publish = True
        first = self.service.publish_review(draft['draft_id'], draft['confirmation'])
        second = self.service.publish_review(draft['draft_id'], draft['confirmation'])
        self.assertEqual(first, second)
        self.assertEqual(self.github.published, [draft['payload']])
        self.assertEqual(draft['payload']['event'], 'COMMENT')

    def test_retry_after_ambiguous_write_does_not_duplicate(self):
        self.service.enable_publish = True
        draft = self.draft()
        self.github.fail_after_post = True
        with self.assertRaises(ReviewError):
            self.service.publish_review(draft['draft_id'], draft['confirmation'])
        result = self.service.publish_review(draft['draft_id'], draft['confirmation'])
        self.assertTrue(result['already_published'])
        self.assertEqual(len(self.github.published), 1)

    def test_expiration(self):
        review_id = self.session()
        self.service.snapshots[review_id].created -= 1801
        with self.assertRaisesRegex(ReviewError, 'expired'):
            self.service.get_file_context(review_id, 'app.py')

    def test_budget_omits_whole_files(self):
        self.github.entries[0]['patch'] = '@@ -0,0 +1 @@\n+' + 'x' * 40001
        self.github.entries[0].pop('additions')
        result = self.service.review_pr('owner/repo', 1)
        self.assertFalse(result['complete'])
        self.assertEqual(result['files'], [])


class LocalTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.root = Path(self.temp.name)
        self.git('init', '-q')
        self.git('config', 'user.email', 'test@example.invalid')
        self.git('config', 'user.name', 'Test')
        (self.root / 'app.py').write_text('value = 1\n')
        self.git('add', '.')
        self.git('commit', '-qm', 'base')
        (self.root / 'app.py').write_text('value = 2\n')
        (self.root / '.env').write_text('DO_NOT_LEAK=private\n')
        (self.root / 'link').symlink_to('/etc/passwd')
        self.git('add', '.')
        self.git('commit', '-qm', 'head')
        self.local = LocalGit(str(self.root))

    def git(self, *args):
        return subprocess.run(['git', '-C', str(self.root), *args], capture_output=True, check=True).stdout

    def test_pinned_content_and_ignored_worktree(self):
        service = ReviewService(local=self.local)
        result = service.review_diff()
        self.assertNotIn('DO_NOT_LEAK', str(result))
        (self.root / 'app.py').write_text('WORKTREE_ONLY')
        self.assertIn('value = 2', service.get_file_context(result['review_id'], 'app.py')['content'])
        self.assertNotIn('WORKTREE_ONLY', str(result))

    def test_symlink_context_denied(self):
        with self.assertRaisesRegex(ReviewError, 'regular'):
            self.local.content(self.local.resolve('HEAD'), 'link')

    def test_option_and_path_injection_denied(self):
        for ref in ('--help', 'HEAD;echo hi', 'HEAD:app.py'):
            with self.assertRaises(ReviewError):
                self.local.resolve(ref)
        with self.assertRaises(ReviewError):
            self.local.content(self.local.resolve('HEAD'), '../outside')

    def test_external_diff_is_never_executed(self):
        self.git('config', 'diff.external', 'sh -c "touch SHOULD_NOT_EXIST"')
        ReviewService(local=self.local).review_diff()
        self.assertFalse((self.root / 'SHOULD_NOT_EXIST').exists())

    def test_output_limit(self):
        with patch('cognisphere_review.local.MAX_OUTPUT', 10):
            with self.assertRaisesRegex(ReviewError, 'exceeds'):
                self.local.resolve('HEAD')


class GitHubTests(unittest.TestCase):
    def client(self, handler):
        github = GitHub('test-token', transport=httpx.MockTransport(handler))
        self.addCleanup(github.close)
        return github

    def test_fixed_origin_and_no_redirect(self):
        calls = []
        def handler(request):
            calls.append(request)
            return httpx.Response(302, headers={'Location': 'https://evil.example'})
        github = self.client(handler)
        with self.assertRaisesRegex(ReviewError, '302'):
            github.pr('owner/repo', 1)
        self.assertEqual(len(calls), 1)
        self.assertEqual(calls[0].url.host, 'api.github.com')

    def test_pagination_and_limit(self):
        pages = []
        def handler(request):
            pages.append(request.url.params['page'])
            return httpx.Response(200, json=[{}] * 100 if len(pages) == 1 else [{}])
        self.assertEqual(len(self.client(handler).files('owner/repo', 1)), 101)
        github = self.client(lambda request: httpx.Response(200, json=[{}] * 100))
        with self.assertRaisesRegex(ReviewError, 'Pagination'):
            github.files('owner/repo', 1)

    def test_response_limit_and_permission_error(self):
        github = self.client(lambda request: httpx.Response(200, content=b'x' * 2_000_001))
        with self.assertRaisesRegex(ReviewError, 'exceeds'):
            github.pr('owner/repo', 1)
        github = self.client(lambda request: httpx.Response(403, json={'message': 'secret-server-message'}))
        with self.assertRaisesRegex(ReviewError, '403') as error:
            github.pr('owner/repo', 1)
        self.assertNotIn('secret-server-message', str(error.exception))

    def test_context_uses_commit_sha_and_checks_file_mode(self):
        calls = []
        def handler(request):
            calls.append(request)
            if '/contents/' in request.url.path:
                self.assertEqual(request.url.params['ref'], 'a' * 40)
                return httpx.Response(200, json={'type': 'file', 'encoding': 'base64',
                    'content': base64.b64encode(b'hello\n').decode()})
            return httpx.Response(200, json={'tree': [{'path': 'app.py', 'mode': '100644',
                                                      'type': 'blob', 'sha': 'b' * 40}]})
        github = self.client(handler)
        self.assertEqual(github.content('owner/repo', 'a' * 40, 'app.py'), 'hello\n')
        self.assertEqual(len(calls), 2)

    def test_github_symlink_context_rejected(self):
        def handler(request):
            if '/contents/' in request.url.path:
                return httpx.Response(200, json={'type': 'file', 'encoding': 'base64',
                    'content': base64.b64encode(b'outside').decode()})
            return httpx.Response(200, json={'tree': [{'path': 'link', 'mode': '120000',
                                                      'type': 'blob', 'sha': 'b' * 40}]})
        with self.assertRaisesRegex(ReviewError, 'Symlinks'):
            self.client(handler).content('owner/repo', 'a' * 40, 'link')

    def test_network_error_does_not_expose_token(self):
        def handler(request):
            raise httpx.ConnectError('test-token', request=request)
        with self.assertRaisesRegex(ReviewError, 'network') as error:
            self.client(handler).pr('owner/repo', 1)
        self.assertNotIn('test-token', str(error.exception))


class SafetyTests(unittest.TestCase):
    def test_hunk_lines_and_redaction(self):
        self.assertEqual(added_lines(PATCH), {2, 3})
        self.assertEqual(added_lines('@@ -0,0 +1,2 @@\n+++ value\n+next'), {1, 2})
        self.assertNotIn('abc123', redact('api_key="abc123"'))
        for path in ('a/../b', './x', '/x', 'a//b', 'a\\b', '.git/config'):
            with self.assertRaises(ReviewError):
                checked_path(path)


if __name__ == '__main__':
    unittest.main()
