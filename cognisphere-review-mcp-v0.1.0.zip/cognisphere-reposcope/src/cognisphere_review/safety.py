"""Input boundaries and best-effort credential redaction (not a DLP system)."""
import fnmatch
from pathlib import PurePosixPath
import re


class ReviewError(ValueError):
    """Safe, actionable error suitable for returning to an MCP client."""


def checked_path(path: str) -> str:
    p = PurePosixPath(path)
    if (not path or p.is_absolute() or any(c in path for c in ('\\', '\x00', '\n', '\r'))
            or any(part in ('.', '..', '.git') for part in path.split('/'))
            or str(p) != path):
        raise ReviewError('Expected a normalized relative file path without traversal.')
    return path


def sensitive(path: str) -> bool:
    patterns = ('.env*', '*.pem', '*.key', '*.p12', '*.pfx', 'id_rsa*', 'id_ed25519*',
                'credentials*', '*secret*', '.npmrc', '.pypirc', '.netrc')
    return any(fnmatch.fnmatch(part.lower(), pattern) for part in PurePosixPath(path).parts for pattern in patterns)


def redact(text: str) -> str:
    text = re.sub(r'-----BEGIN [^-\n]*PRIVATE KEY-----.*?(?:-----END [^-\n]*PRIVATE KEY-----|\Z)',
                  '[REDACTED PRIVATE KEY]', text, flags=re.S)
    text = re.sub(r'\b(?:gh[pousr]_[A-Za-z0-9]{20,}|github_pat_[A-Za-z0-9_]{20,}|sk-[A-Za-z0-9_-]{20,}|AKIA[A-Z0-9]{16})\b', '[REDACTED]', text)
    text = re.sub(r'(?i)((?:api[_-]?key|access[_-]?token|password|secret)\s*["\x27]?\s*[:=]\s*)["\x27][^"\x27\n]+["\x27]', r'\1"[REDACTED]"', text)
    return text


def added_lines(patch: str) -> set[int]:
    result = set()
    current = None
    for line in patch.splitlines():
        match = re.match(r'^@@ -\d+(?:,\d+)? \+(\d+)(?:,\d+)? @@', line)
        if match:
            current = int(match[1])
        elif current is not None:
            if line.startswith('+'):
                result.add(current)
                current += 1
            elif line.startswith(' '):
                current += 1
    return result
