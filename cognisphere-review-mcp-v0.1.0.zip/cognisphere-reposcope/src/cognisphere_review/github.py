"""Fixed-origin GitHub REST client with bounded responses and no automatic writes/retries."""
import base64
import re
from urllib.parse import quote

import httpx

from .safety import ReviewError, checked_path


class GitHub:
    def __init__(self, token: str = '', transport=None):
        headers = {'Accept': 'application/vnd.github+json', 'X-GitHub-Api-Version': '2022-11-28',
                   'User-Agent': 'cognisphere-review-mcp/0.1.0'}
        if token:
            headers['Authorization'] = 'Bearer ' + token
        self.client = httpx.Client(base_url='https://api.github.com', headers=headers,
                                   timeout=20, follow_redirects=False, trust_env=False, transport=transport)

    def close(self):
        self.client.close()

    def request(self, method, path, payload=None):
        if not path.startswith('/repos/') or '..' in path.split('/'):
            raise ReviewError('Invalid API path.')
        try:
            with self.client.stream(method, path, json=payload) as response:
                if not 200 <= response.status_code < 300:
                    raise ReviewError(f'GitHub HTTP {response.status_code}. Check permissions, rate limits and repository access.')
                data = bytearray()
                for chunk in response.iter_bytes():
                    data.extend(chunk)
                    if len(data) > 2_000_000:
                        raise ReviewError('GitHub response exceeds 2 MB; narrow the review.')
                import json
                return json.loads(data)
        except httpx.HTTPError:
            raise ReviewError('GitHub network error. A failed publish may have succeeded remotely; retry the same draft to check.') from None

    @staticmethod
    def repo(repo: str) -> str:
        if not re.fullmatch(r'[A-Za-z0-9_.-]+/[A-Za-z0-9_.-]+', repo) or any(p in ('.', '..') for p in repo.split('/')):
            raise ReviewError('Repository must be owner/name.')
        return repo

    def pr(self, repo, number):
        if type(number) is not int or number < 1:
            raise ReviewError('PR number must be positive.')
        return self.request('GET', f'/repos/{self.repo(repo)}/pulls/{number}')

    def pages(self, path, max_pages=10):
        items = []
        for page in range(1, max_pages + 1):
            batch = self.request('GET', f'{path}?per_page=100&page={page}')
            if not isinstance(batch, list):
                raise ReviewError('Unexpected GitHub list response.')
            items.extend(batch)
            if len(batch) < 100:
                return items
        raise ReviewError('Pagination safety limit reached; refusing an incomplete result.')

    def files(self, repo, number):
        return self.pages(f'/repos/{self.repo(repo)}/pulls/{number}/files', max_pages=3)

    def content(self, repo, sha, path):
        if not re.fullmatch(r'[a-f0-9]{40,64}', sha):
            raise ReviewError('Context requires an immutable commit SHA.')
        result = self.request('GET', f'/repos/{self.repo(repo)}/contents/{quote(checked_path(path), safe="/")}?ref={sha}')
        if not isinstance(result, dict) or result.get('type') != 'file' or result.get('encoding') != 'base64':
            raise ReviewError('Context only supports regular text files under the GitHub Contents API size limit.')
        # GitHub may dereference symlinks through Contents; reject via Git tree metadata.
        parent, _, filename = path.rpartition('/')
        tree_sha = sha
        components = [*parent.split('/'), filename] if parent else [filename]
        for index, component in enumerate(components):
            tree = self.request('GET', f'/repos/{self.repo(repo)}/git/trees/{tree_sha}')
            if tree.get('truncated'):
                raise ReviewError('Cannot verify file type in a truncated tree.')
            entry = next((e for e in tree['tree'] if e['path'] == component), None)
            if not entry:
                raise ReviewError('File missing from commit tree.')
            tree_sha = entry['sha']
            if index < len(components) - 1 and entry['type'] != 'tree':
                raise ReviewError('Invalid context tree.')
        if entry['mode'] not in ('100644', '100755'):
            raise ReviewError('Symlinks and submodules are not available as context.')
        try:
            return base64.b64decode(result['content']).decode('utf-8')
        except (ValueError, UnicodeDecodeError):
            raise ReviewError('Non-UTF-8 context is unsupported.') from None

    def reviews(self, repo, number):
        return self.pages(f'/repos/{self.repo(repo)}/pulls/{number}/reviews')

    def publish(self, repo, number, payload):
        return self.request('POST', f'/repos/{self.repo(repo)}/pulls/{number}/reviews', payload)
