"""stdio MCP entry point. stdout belongs exclusively to the protocol."""
import os

from mcp.server.fastmcp import FastMCP
from mcp.types import ToolAnnotations

from .github import GitHub
from .local import LocalGit
from .service import Finding, GUIDANCE, ReviewService


def create_server(service=None):
    if service is None:
        root = os.environ.get('REVIEW_LOCAL_ROOT')
        repos = [p.strip() for p in os.environ.get('REVIEW_GITHUB_REPOS', '').split(',') if p.strip()]
        service = ReviewService(local=LocalGit(root) if root else None,
                                github=GitHub(os.environ.get('GITHUB_TOKEN', '')) if repos else None,
                                allowed_repos=repos,
                                enable_publish=os.environ.get('REVIEW_ENABLE_PUBLISH') == '1')
    mcp = FastMCP('Cognisphere Review', instructions=GUIDANCE)
    read = ToolAnnotations(readOnlyHint=True, destructiveHint=False, openWorldHint=True)

    @mcp.tool(annotations=read)
    def review_diff(base: str = 'HEAD~1', head: str = 'HEAD') -> dict:
        """Prepare committed local Git changes for YOUR analysis. No model/API calls, no working-tree edits."""
        return service.review_diff(base, head)

    @mcp.tool(annotations=read)
    def review_pr(repository: str, number: int) -> dict:
        """Read an allowlisted open GitHub PR and capture its immutable review context. YOU infer findings."""
        return service.review_pr(repository, number)

    @mcp.tool(annotations=read)
    def get_file_context(review_id: str, path: str, start_line: int = 1, end_line: int = 120) -> dict:
        """Read up to 200 numbered lines from an included changed file at the captured HEAD commit."""
        return service.get_file_context(review_id, path, start_line, end_line)

    @mcp.tool(annotations=ToolAnnotations(readOnlyHint=True, destructiveHint=False, openWorldHint=True))
    def prepare_review(review_id: str, summary: str, findings: list[Finding]) -> dict:
        """Validate findings on added lines and return the exact publication preview. Does NOT publish."""
        return service.prepare_review(review_id, summary, findings)

    @mcp.tool(annotations=ToolAnnotations(readOnlyHint=False, destructiveHint=False, idempotentHint=False, openWorldHint=True))
    def publish_review(draft_id: str, confirmation: str) -> dict:
        """Publish a COMMENT review to GitHub ONLY after explicit user approval of the prepared preview.

        Requires server-side opt-in and matching confirmation. Never approves, merges, or edits code.
        """
        return service.publish_review(draft_id, confirmation)

    @mcp.prompt()
    def review_changes() -> str:
        """Evidence-first review workflow for the host model."""
        return GUIDANCE + ('\n1. Call review_diff or review_pr. 2. Inspect coverage and changed lines. '
                          '3. Request get_file_context as needed. 4. Return only supported findings '
                          'with path, added line, severity, trigger and impact. 5. For GitHub, prepare_review '
                          'only if findings exist. Present preview and wait for explicit publication approval. '
                          'No findings means no evidence found in the reviewed scope, not proof of correctness.')

    return mcp


def main():
    create_server().run(transport='stdio')


if __name__ == '__main__':
    main()
