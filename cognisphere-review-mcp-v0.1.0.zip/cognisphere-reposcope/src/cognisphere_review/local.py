"""Read committed Git objects; never run repository scripts, hooks or diff drivers."""
import os
from pathlib import Path
import re
import subprocess
import threading

from .safety import ReviewError, checked_path

MAX_OUTPUT = 2_000_000


class LocalGit:
    def __init__(self, root: str):
        self.root = Path(root).resolve(strict=True)
        # Strip inherited Git controls, credentials and config overrides.
        self.env = {k: v for k, v in os.environ.items()
                    if not k.startswith('GIT_') and k in ('PATH', 'SystemRoot', 'WINDIR', 'TMPDIR', 'TEMP', 'TMP')}
        self.env.update(GIT_CONFIG_NOSYSTEM='1', GIT_CONFIG_GLOBAL=os.devnull,
                        GIT_TERMINAL_PROMPT='0', GIT_OPTIONAL_LOCKS='0', GIT_NO_REPLACE_OBJECTS='1',
                        GIT_NO_LAZY_FETCH='1', LC_ALL='C')
        actual = self.run('rev-parse', '--show-toplevel').decode().strip()
        if Path(actual).resolve() != self.root:
            raise ReviewError('REVIEW_LOCAL_ROOT must be the repository root, not a subdirectory.')

    def run(self, *args: str) -> bytes:
        command = ['git', '-C', str(self.root), '-c', 'core.hooksPath=' + os.devnull,
                   '-c', 'core.fsmonitor=false', '-c', 'core.quotePath=false',
                   '-c', 'protocol.allow=never', *args]
        process = subprocess.Popen(command, env=self.env, stdout=subprocess.PIPE, stderr=subprocess.DEVNULL)
        data = bytearray()

        def read():
            assert process.stdout is not None
            while chunk := process.stdout.read(65536):
                data.extend(chunk)
                if len(data) > MAX_OUTPUT:
                    process.kill()
                    break

        reader = threading.Thread(target=read, daemon=True)
        reader.start()
        try:
            process.wait(timeout=15)
            reader.join(timeout=2)
            if reader.is_alive():
                raise ReviewError('Git output stream did not close.')
            if len(data) > MAX_OUTPUT:
                raise ReviewError('Git output exceeds 2 MB. Review a smaller commit range.')
            if process.returncode:
                raise ReviewError('Git command failed. Verify refs, repository access and complete local objects.')
            return bytes(data)
        except subprocess.TimeoutExpired:
            raise ReviewError('Git operation timed out.') from None
        finally:
            if process.poll() is None:
                process.kill()
            process.wait()
            reader.join(timeout=2)
            if process.stdout:
                process.stdout.close()

    def resolve(self, ref: str) -> str:
        if not re.fullmatch(r'[A-Za-z0-9_][A-Za-z0-9_./~-]{0,199}', ref):
            raise ReviewError('Use a branch, tag or commit SHA (no Git options or complex revision expressions).')
        sha = self.run('rev-parse', '--verify', '--end-of-options', ref + '^{commit}').decode().strip()
        if not re.fullmatch(r'[a-f0-9]{40,64}', sha):
            raise ReviewError('Invalid Git commit object.')
        return sha

    def files(self, base: str, head: str) -> list[str]:
        raw = self.run('diff', '--no-ext-diff', '--no-textconv', '--no-renames', '--name-only', '-z', base, head, '--')
        try:
            return [checked_path(p) for p in raw.decode('utf-8').split('\0') if p]
        except UnicodeDecodeError:
            raise ReviewError('Non-UTF-8 file names are unsupported.') from None

    def patch(self, base: str, head: str, path: str) -> str:
        return self.run('diff', '--no-ext-diff', '--no-textconv', '--no-renames', '--no-color',
                        '--unified=3', base, head, '--', ':(literal)' + checked_path(path)).decode('utf-8', errors='replace')

    def content(self, sha: str, path: str) -> str:
        path = checked_path(path)
        entry = self.run('ls-tree', '-z', sha, '--', ':(literal)' + path)
        if not entry.startswith((b'100644 blob ', b'100755 blob ')):
            raise ReviewError('Context only supports regular tracked files present at this commit.')
        try:
            return self.run('show', sha + ':' + path).decode('utf-8')
        except UnicodeDecodeError:
            raise ReviewError('Binary/non-UTF-8 context is unsupported.') from None
