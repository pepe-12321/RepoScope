# Verification for v0.1.0

Implemented test coverage:

- Local committed diffs and pinned context despite worktree changes.
- Rejection of ref option injection, traversal and symlink context.
- External Git diff command is not executed.
- Git output and HTTP response size limits.
- Repository allowlist, closed PRs and pagination safety limits.
- Stale base/head checks during collection and before publication.
- Sensitive filenames, sensitive renames, partial patches and context budgets.
- Credential redaction and review-text rejection for known patterns.
- Added-line validation, duplicate findings, draft expiry and publication opt-in.
- Exact prepared payload publication and ambiguous-network retry deduplication.
- Real stdio MCP initialize, tool listing, local review, error response and prompt listing.

GitHub is mocked: no test sends a review or notification to real users. Live authenticated read/write verification and actual OpenCode UI integration are outstanding. No model-quality benchmark has been run; these tests establish implementation behavior, not how well a chosen model detects bugs.

The development environment uses Python 3.12, MCP SDK 1.29.0, httpx 0.28.1 and Pydantic 2.13.4. An upstream Pydantic settings warning about the SDK's lifespan annotation appears on stderr, without breaking the stdio protocol test.
