# Architecture

The MCP host owns model reasoning and user approval. `server.py` exposes tools through the official Python SDK over stdio. `service.py` manages bounded, expiring snapshots and drafts. `local.py` reads immutable Git objects; `github.py` wraps only the needed GitHub REST endpoints; `safety.py` validates paths, parses added lines and redacts common credential patterns.

```mermaid
flowchart TD
  Host["MCP host and model"] --> Server["stdio tool server"]
  Server --> Sessions["Review sessions and drafts"]
  Sessions --> Git["Local Git objects"]
  Sessions --> API["GitHub REST API"]
  Sessions --> Preview["Exact review preview"]
  Preview --> Approval["Host obtains user approval"]
  Approval --> Publish["Enabled publish tool"]
  Publish --> API
```

Review sessions pin commit SHAs rather than branch names. A context request only reads an included changed file at the captured head. GitHub file lists are read with pagination and checked against `changed_files`; freshness is checked again after collection. Patch counts detect some incomplete GitHub patches. The API remains the source of truth for the returned diff; completeness cannot prove model understanding or bug absence.

The service retains at most 32 snapshots and 32 drafts for a 30-minute TTL. A synchronous reentrant lock serializes service operations, including publication. This trades concurrency for simple session consistency in the MVP. It is designed for one user and one stdio host, not multi-tenant hosting.

Only COMMENT review events are emitted. Findings are pinned to added lines on the RIGHT side. Deletion-only issues can be described to the user, but cannot be submitted as inline findings through v0.1.

No LLM provider implementation is included. Connecting OpenCode to a local model or BYOK provider is a host configuration decision.
