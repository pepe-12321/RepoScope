# Cognisphere Review MCP — inicio rápido

El servidor le entrega cambios y contexto a la IA de OpenCode. La IA hace el análisis; el MCP valida y publica comentarios cuando lo autorizas. No necesita una segunda API de IA.

## Instalar en Linux

Abre una terminal dentro de esta carpeta:

```bash
python3 -m venv .venv
.venv/bin/python -m pip install .
```

Requiere Python 3.11 o posterior y Git. Copia la configuración del README a tu configuración de OpenCode, ajustando la ruta del ejecutable y `REVIEW_LOCAL_ROOT` al proyecto que quieras revisar. El README distingue la configuración de OpenCode v1 y v2.

## Primera revisión

Pídele a OpenCode:

> Usa cognisphere-review para revisar HEAD~1 contra HEAD. Busca bugs reales introducidos por los cambios. Lee contexto cuando lo necesites y explica archivo, línea, condición que causa el fallo e impacto. No publiques nada.

Se revisan dos commits, no los cambios sin guardar o sin commit. Si solo tienes un commit, elige otro proyecto o crea un segundo commit con cambios de prueba.

## Revisar una PR

Configura `REVIEW_GITHUB_REPOS` con `propietario/repositorio`. Para repos privados, proporciona `GITHUB_TOKEN` mediante el entorno del proceso, sin guardarlo en el código. La conexión de GitHub de ChatGPT no se transfiere automáticamente a tu PC.

> Usa review_pr para revisar la PR número 1 de propietario/repositorio. Entrega hallazgos con evidencia y señala si quedaron archivos fuera. No publiques todavía.

Cuando quieras publicar: habilita `REVIEW_ENABLE_PUBLISH=1`, reinicia la conexión MCP, vuelve a revisar la PR y pide preparar la revisión. El agente debe mostrarte el texto exacto y esperar tu autorización antes de usar `publish_review`.

## Estado real

Esta es una primera versión funcional con pruebas automatizadas, no un reemplazo completo de CodeRabbit. No ejecuta pruebas de tu proyecto ni garantiza encontrar todos los errores. La calidad del análisis depende del modelo conectado. Los comentarios automáticos al abrir una PR, la interfaz web y las revisiones del staging quedan para otras versiones.
