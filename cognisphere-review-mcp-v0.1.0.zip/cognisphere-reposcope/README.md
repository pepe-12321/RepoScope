# Cognisphere Review MCP

**Your model. Your code. Evidence before comments.**

A local MCP server that gives your coding assistant Git diffs and file context, then helps it publish precise GitHub review comments. Inspired by the code-review workflow of tools like CodeRabbit; not affiliated with them.

**Status: v0.1.0 MVP.** The server gathers evidence and validates publication. Your MCP client's model performs the actual reasoning. There is no built-in LLM, cloud backend, subscription, webhook bot or automatic review trigger.

## What it does

| Tool | Purpose |
|---|---|
| `review_diff` | Compare two committed revisions in a configured local Git repository. |
| `review_pr` | Capture an open, allowlisted GitHub PR and its base/head SHAs. |
| `get_file_context` | Return up to 200 numbered lines from a reviewed changed file at the captured head. |
| `prepare_review` | Validate findings and produce an exact review preview. No publication. |
| `publish_review` | Publish that preview as a `COMMENT` review after explicit user approval. |

The `review_changes` MCP prompt guides the host through an evidence-first workflow. Findings have a path, added line, severity P0–P3, title, evidence and suggested fix. No findings means “nothing supported by the evidence reviewed,” not “the code is safe.”

## Install

Requires Python 3.11+ and Git. From this project's directory:

```bash
python3 -m venv .venv
.venv/bin/python -m pip install .
```

The package is not published to PyPI. Install from source or the supplied wheel. This MVP uses the official MCP Python SDK **v1 maintenance line**, constrained to `>=1.29,<2`; v2 migration is a separate compatibility task.

## Connect to OpenCode

Merge this into your existing OpenCode configuration; replace both absolute paths. Use the executable inside the environment where you installed the package:

```json
{
  "$schema": "https://opencode.ai/config.json",
  "mcp": {
    "servers": {
      "cognisphere-review": {
        "type": "local",
        "command": ["/absolute/path/to/cognisphere-reposcope/.venv/bin/cognisphere-review"],
        "protocol": "legacy",
        "environment": {
          "REVIEW_LOCAL_ROOT": "/absolute/path/to/project-to-review",
          "REVIEW_ENABLE_PUBLISH": "0"
        }
      }
    }
  }
}
```

This example follows OpenCode v2 configuration. For OpenCode v1, place `cognisphere-review` directly under `mcp`, remove `protocol`, and use `enabled: true`. Check your installed client version before merging configuration. Other stdio MCP clients use the same executable, with their own `command`, `args` and environment configuration format. No HTTP port is exposed.

Ask your assistant:

> Use cognisphere-review to review HEAD~1 against HEAD. Read context when needed. Report only actionable regressions with file, line, trigger and impact. Do not publish anything.

The project being reviewed needs at least two commits for the defaults. Pass explicit `base` and `head` refs otherwise. Changes in the working tree, staging area and untracked files are **not included** in v0.1. Comparisons are direct base-to-head, not automatically merge-base comparisons.

## GitHub reviews

Configure `REVIEW_GITHUB_REPOS` as a comma-separated allowlist, for example `DarioDGR12/cognisphere-reposcope`. Set `GITHUB_TOKEN` in the MCP process environment for private repos or authenticated access. Do not commit a token to this repository or paste one into a review.

For a fine-grained token, select only the intended repositories and give Contents: read and Pull requests: read. Publication also needs Pull requests: write. Public read-only calls can work without a token, subject to GitHub rate limits. The ChatGPT GitHub connection is **not** automatically available to this locally installed server.

1. `review_pr(repository="owner/repo", number=42)` returns a `review_id`, patches and coverage information.
2. The host model analyzes changes and requests `get_file_context` if needed.
3. `prepare_review` validates up to 20 findings and returns the exact GitHub payload plus a confirmation string.
4. The host shows the preview to the user and waits for approval.
5. With `REVIEW_ENABLE_PUBLISH=1` configured by the user, `publish_review` sends the matching draft.

Publication only comments; it cannot approve, request changes, merge or modify code. If either PR head or base changes, regenerate the review. Local sessions cannot publish to GitHub. Sessions and drafts expire after 30 minutes or server restart, and only the most recent 32 of each are retained.

Example finding passed to `prepare_review`:

```json
{
  "path": "src/calculate.py",
  "line": 24,
  "severity": "P1",
  "title": "Zero input now raises an exception",
  "evidence": "When count is zero, the new division raises ZeroDivisionError before the existing fallback can run.",
  "suggestion": "Handle zero before dividing and add a regression test."
}
```

This is an illustrative finding, not a claim about this repository. The path and line must exist as an added line in the actual captured PR.

## Privacy and boundaries

- Local review has no network dependency. GitHub tools contact only `api.github.com` with redirects disabled.
- Code returned through MCP reaches the host model. With a remote model, it may leave your computer according to that client's configuration.
- Known sensitive filenames are excluded, and common credential patterns are redacted on a best-effort basis. This does **not** guarantee secret removal.
- Git reads use committed objects, disable external diff/textconv and hooks, and reject traversal. Context rejects symlinks and submodules. Configure a trusted local Git repository; this is not a sandbox for hostile `.git` metadata or concurrent filesystem mutation.
- Repository content is untrusted input. Prompt-injection resistance depends partly on the host model and its tool permissions.
- The confirmation string binds publication to the preview; it is **not proof that a human approved it**. Keep host-side approval for `publish_review` enabled.
- No telemetry, automatic tests, command execution from code, or persistent review database.

See [SECURITY.md](SECURITY.md) for threat boundaries and [docs/architecture.md](docs/architecture.md) for implementation details.

## Coverage limits

PRs with more than 100 changed files are rejected. Local scans include at most 100 file patches. Patches are limited to 40 KB per file and 200 KB total; API and Git responses are capped at 2 MB, with timeouts. Missing, binary, oversized, sensitive and detectably incomplete patches are listed as skipped. Context is limited to included changed text files at the captured head; deleted-file context and unchanged dependency context are not supported yet.

GitHub PR patches use GitHub's comparison semantics. Captured base SHA is used for freshness checks, not presented as the preimage for every patch. GitHub can change between the last freshness check and the POST; the explicit commit SHA keeps the review attached to the inspected head, but the API does not provide an atomic compare-and-publish operation.

Duplicate detection uses a content marker and checks existing reviews before retrying. It is best effort across independent server processes and GitHub's consistency delays. Review text is Markdown and should be checked for unwanted mentions or links before approval.

## Development and tests

```bash
python3 -m pip install -e .
python3 -m unittest discover -s tests -v
python3 -m pip wheel --no-deps --no-build-isolation . -w dist
```

Tests use temporary Git repositories, a real MCP stdio subprocess and mocked GitHub HTTP responses. They do not publish reviews or exercise a live authenticated GitHub write. See [docs/verification.md](docs/verification.md).

## Roadmap

- Working-tree/staged snapshots with reliable freshness checks.
- Safe, explicit access to related unchanged files.
- Benchmarked review quality on a small labeled set of real bugs.
- Optional persistent draft storage and cross-process publication coordination.
- MCP SDK v2 compatibility and client integration testing.

## References

- [Official MCP Python SDK v1](https://py.sdk.modelcontextprotocol.io/v1/)
- [OpenCode MCP configuration](https://opencode.ai/docs/mcp-servers)
- [GitHub pull request reviews API](https://docs.github.com/en/rest/pulls/reviews)

MIT licensed. Built for Cognisphere.
