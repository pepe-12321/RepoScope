# Security boundaries

This is a local stdio tool server, not a sandbox or an autonomous security auditor.

## Trusted inputs

The person running the server controls its installation, environment, local Git root, Git executable and repository allowlist. Run under an account with only the access needed. The host must gate publication with explicit human approval. A model can read the confirmation returned by prepare_review, so the confirmation is a binding mechanism, not human authentication.

The configured Git root must be trusted. Git can read metadata, alternates and configuration under `.git`; disabling hooks and diff drivers is not equivalent to containing a hostile repository. Use a clean isolated checkout/container when appropriate. Concurrent modification of the local object database is outside the threat model.

## Untrusted inputs

PR content, code, filenames and model findings are untrusted. Paths and refs are validated, requests are restricted to a fixed GitHub origin, HTTP redirects and environment proxies are disabled, and publication accepts only previously captured PRs. No shell is used for Git commands. Secret redaction is incomplete by design; do not rely on it as a data-loss-prevention boundary.

## Publication

Disabled unless REVIEW_ENABLE_PUBLISH=1. Drafts bind repository, PR, head and payload. A lock serializes tool operations inside one process. Before writing, the server checks that the PR is open and base/head still match. A content marker reduces retry duplicates. Different server processes are not coordinated; the GitHub API has no atomic freshness precondition for posting a review. A network failure may happen after GitHub accepted the write; retry the same draft so it checks for the marker first.

## Reporting

Do not include real tokens, private source code or exploit credentials in public issues. Report non-sensitive reproduction steps to the repository owner; use a private security advisory if the repository has enabled that feature. No private reporting address or security response SLA has been established yet.
